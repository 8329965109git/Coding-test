def add(a, b):
    print(a + b)


add(5, 6)
