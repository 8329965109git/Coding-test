# Python
Basics of python
Function ,List, Tuple, Set and directories, Inheritance
Welcome to python programming