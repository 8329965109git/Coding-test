from django.contrib import admin
from .models import drink
# Register your models here.
admin.site.register(drink)