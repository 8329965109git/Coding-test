class A:
    def myfunc(self):
        print("myfunc() being called")


#next part in for_else.py