import string
with open("D:/Demo.txt","a") as fw:
    data="Depali Rane"
    fw.write(data)

# with open("D:/Demo.txt","r") as fr:
#     read_data=fr.read()
#     print(read_data)
#     fr.seek(0)
#     read_line=fr.readline()
#     print(read_line)
#     print(fr.tell())
#
